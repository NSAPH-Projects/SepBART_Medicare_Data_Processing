opts_1 <- Opts()
opts_2 <- Opts(update_sigma = FALSE)

forest_1 <- MakeForest(hypers = hypers, opts = opts_1)
forest_2 <- MakeForest(hypers = hypers, opts = opts_2)

mu_hat_2 <- numeric(length(Y))

#' Model: Y = forest_1(t,X) + forest_2(t,X) + sigma * error
#' First, update forest_1(t,X) using Y - forest_2(t,X)

R <- Y - mu_hat_2
mu_hat_1 <- as.numeric(forest_1$do_gibbs(X, R, scaled_t, X, scaled_t, 1))

#' Now, update forest_2(t,X) using Y - forest_1(t,X)

forest_2$set_sigma(forest_1$get_sigma())
R <- Y - mu_hat_1
mu_hat_2 <- as.numeric(forest_2$do_gibbs(X, R, scaled_t, X, scaled_t, 1))

#' forest(t,X) = sum_m cos(theta_m * t_m + omega_m) * tree_m(X)